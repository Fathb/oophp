<?php

require_once 'App/Init.php';

$MCML = new MC ("MAGIC CHESS TOURNEY", 15000, "21-29 juni 2020", "30-6-2020", "1-3 juli 2020", "BO4 ke babak selanjutnya", "lemon");
      
$ML = new ML("MOBILE LEGENDS TOURNEY",40000,"21-29 juni 2020", "30-60-2020", "3-5 juli 2020", "BO1, semifinala dan final BO3", "RRQ");
      
echo "<hr>";
echo $MCML->getlabel();
echo "<br>";
echo $ML->getlabel();
echo "<hr>";
$info = new cetakinfotour();
echo $info->cetak ($MCML);
echo "<hr>";
echo $info->cetak ($ML);
echo "<hr>";
$MCML->setdisc(1000);
echo $MCML->getfee();
echo "<hr>";

$ctk = new cetakinfotour;
$ctk->tambahtour ($MCML);
$ctk->tambahtour ($ML);
echo $ctk->cetak ();
echo "<hr>";

use App\Services\User as Servicesuser;
use App\Tourney\User as Tourneyuser;

new Servicesuser();
echo "<br>";
new Tourneyuser();

?>