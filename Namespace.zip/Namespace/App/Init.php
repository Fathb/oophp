<?php

//require_once 'Tourney/infoturnament.php';
//require_once 'Tourney/turnament.php';
//require_once 'Tourney/mc.php';
//require_once 'Tourney/ml.php';
//require_once 'Tourney/cetakinfotour.php';
//require_once 'Tourney/User.php';
//require_once 'Services/User.php';

spl_autoload_register(function ($class){
  $class = explode('\\', $class);
  $class = end($class);
  require_once 'Tourney/'.$class.'.php';
});
spl_autoload_register(function ($class){
  $class = explode('\\', $class);
  $class = end($class);
  require_once 'Services/'.$class.'.php';
});