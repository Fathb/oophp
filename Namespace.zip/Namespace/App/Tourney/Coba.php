<?php

class Coba {
  public function __construct(){
    "ini class mboh";
  }
}