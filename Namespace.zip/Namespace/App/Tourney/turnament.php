<?php

abstract class turnament {
  public  $nama;
  private $feeregist;
  public  $timeregist,
          $TM,
          $matchday,
          $rule,
          $payment;
  protected $disc;
          
  
  public function __construct ($nama = "nama", $feeregist = "harga", $timeregist = "tanggal", $TM = "tanggal", $matchday = "tanggal", $rule = "peraturan", $payment= "OVO, DANA, GO-PAY, BRI", $disc=0){
    $this->nama=$nama;
    $this->feeregist=$feeregist;
    $this->timeregist=$timeregist;
    $this->TM=$TM;
    $this->matchday=$matchday;
    $this->rule=$rule;
    $this->payment=$payment;
    $this->disc=$disc;
  }
  
          
  public function getlabel (){
    return "$this->nama, $this->feeregist, $this->timeregist";
  }
  
  abstract public function tourinfo ();
  
  public function setdisc ($disc){
    $this->disc = $disc;
  }
  public function getfee (){
    return $this->feeregist-$this->disc;
  }
}