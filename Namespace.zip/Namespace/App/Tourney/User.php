<?php namespace App\Tourney;

class User {
  public function __construct (){
    echo "ini adalah kelas ".__class__;
  }
}