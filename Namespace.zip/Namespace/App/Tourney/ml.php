<?php

class ML extends turnament implements infoturnament {
  public $tim;
  
  public function __construct ($nama = "nama", $feeregist = "harga", $timeregist = "tanggal", $TM = "tanggal", $matchday = "tanggal", $rule = "peraturan", $tim, $payment= "OVO, DANA, GO-PAY, BRI"){
    
    parent::__construct($nama, $feeregist, $timeregist, $TM, $matchday, $rule, $payment);
    $this->tim=$tim;
  }
  
  public function tourinfo () {
    $str = "{$this->getlabel()} | {$this->TM} | {$this->matchday} <br> (peraturan : {$this->rule} | {$this->payment}";
    return "$str";
  }
  
  public function infotour(){
    $str = "{$this->tourinfo()} <br> kategori tourney : tim <br> peserta : {$this->tim}";
    return "$str";
  }
}