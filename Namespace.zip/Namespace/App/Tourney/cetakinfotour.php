<?php

class cetakinfotour {
  public $listtour = array ();
  public function tambahtour (turnament $tour){
    $this->listtour[]=$tour;
  }
  public function cetak(){
    $str = "list tourney : <br>";
    $ak = 1;
    
    foreach ($this->listtour as $lt){
      $str .= $ak++. ". {$lt->infotour()} <br>";
    }
    return $str;
  }
}