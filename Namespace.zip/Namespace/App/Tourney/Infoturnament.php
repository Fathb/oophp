<?php

interface infoturnament {
    public function infotour ();
}