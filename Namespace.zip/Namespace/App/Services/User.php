<?php namespace App\Services;

class User {
  public function __construct (){
    echo "ini adalah kelas ".__class__;
  }
}